Ext.define('istsos.view.BasePage', {
    extend: 'istsos.view.ui.BasePage',
    initComponent: function() {
        var me = this;
        me.callParent(arguments);
    }
});