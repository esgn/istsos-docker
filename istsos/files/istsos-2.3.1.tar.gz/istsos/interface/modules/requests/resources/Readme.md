# ext-theme-neptune-bac8fda6-17d1-4644-bba3-b378c3960b65/resources

This folder contains static resources (typically an `"images"` folder as well).
